﻿There icons are used for the taskbar. If you want to use a custom icon, put it here 
and rename it to tray_white.ico and tray_black.ico.

Tons of svg icons: https://materialdesignicons.com/
Convert svg to ico: https://convertio.co/svg-ico/